<?php

require_once 'connexionDB.php';

class employe extends ConnexionDB  {

	/**
	 * Retourne la liste de tous les employés
	 */
	public function getAllEmploye() {
        return $this->cnx->query("SELECT * FROM tbl_employe")->fetchAll();
	}

	/**
	 * Retourne les données sur un employé
	 */
	public function getEmploye($id) {
		$sql = $this->cnx->prepare("SELECT * FROM tbl_employe WHERE emp_id=?");
		$sql->execute( array($id) );
		return $sql->fetch();
	}

	/**
	 * Ajoute un employé avec certaines données
	 */
	public function add($empl)
	{
		$sql = $this->cnx->prepare("INSERT INTO tbl_employe (emp_pnom,emp_nom,emp_email,emp_tel) 
		VALUES (?,?,?,?)");
		$sql->execute( array($empl['prenom'],$empl['nom'],$empl['email'],$empl['tel']) );
		return $sql->rowCount();
	}

	/**
	 * Modification des données d'un employé identifé
	 */
	public function edit($empl,$id)
	{
		/* Application de la modification d'un employé à la base de données */ 
	}

	/**
	 * Supprime un employé est ses données
	 */
	public function delete($id)
	{
		$sql = $this->cnx->prepare("DELETE FROM tbl_employe WHERE emp_id = ?");
		$sql->execute( array($id) );
		return $sql->rowCount();
	}
}