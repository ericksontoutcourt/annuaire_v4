<?php
/** BTS SIO Lycée Pierre Poivre
** Outils annuaire pour la gestion de projet
** @author P COMBE
* @copyright BTS SIO
* @package non de l'étudiant
* @version 0.4
*/
/**
* ctrl = controleur
* mth = méthode du controleur
*/

// Cela signifie que vous ne souhaitez pas voir le résultat de votre script mis une fois pour toutes en cache, 
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Cache-Control: no-cache");
header("Pragma: no-cache");

// Contrôleur
if (isset($_GET['ctrl'])) {
	$c_name = ucfirst(strtolower($_GET['ctrl'])).'Controller';
}
else {
	// Contrôleur par défaut
	$c_name = "AccueilController";
}

// Méthode
if (isset($_GET['mth'])) {
	$method = $_GET['mth'];
}
else {
	// Méthode par defaut
	$method = "index";
}


// Recherche si la page existe
$c_path = 'controller/'.$c_name.'.php';

if (file_exists($c_path)) {
	require_once $c_path;
	if (class_exists($c_name) && method_exists($c_name, $method)) {
		$c_object = new $c_name();
		$c_object->$method();
	} else {
		die('Page non trouvée 404');
	}
} else {
	die('Page non trouvée 404');
}