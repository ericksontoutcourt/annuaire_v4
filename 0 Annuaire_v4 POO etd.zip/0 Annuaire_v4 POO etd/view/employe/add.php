<?php include "templates/header.php";?>
<section>
    <h2>Ajouter un employé</h2>
    <article>
        <form action="?ctrl=employe&mth=add" method="post">
            <label for="prenom">Prénom</label><br>
            <input type="text" name="prenom" id="prenom" placeholder="Prénom"> <br><br>
            <label for="nom">Nom</label><br>
            <input type="text" name="nom" id="nom" placeholder="Nom"><br><br>
            <label for="email">Adresse mail</label><br>
            <input type="text" name="email" id="email" placeholder="xyzøxuz.com"><br><br>
            <label for="dateEmb">Date embauche</label><br>
            <input type="date" name="dateEmb" id="dateEmb" ><br><br>
            <label for="tel">Téléphone </label><br>
            <input type="text" name="tel" id="tel" placeholder="0692 11 22 33">
            <br><br>
            <input type="submit" name="submit" value="Ajouter">
            <br><br>

            <?php if ($errors) {
                    ?>
                    <h3>Erreur:</h3>
                    <ul>
                        <?php foreach ($errors as $value) { ?>
                            <li><?php echo $value; ?></li>
                        <?php } ?>
                    </ul>
            <?php } ?>
        </form>
    </article>
</section>
<?php include "templates/footer.php";?>