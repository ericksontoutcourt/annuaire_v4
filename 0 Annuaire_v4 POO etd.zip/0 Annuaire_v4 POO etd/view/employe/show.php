<?php include "templates/header.php";?>
<section>
	<h2>Afficher la fiche de <?php echo $employe['emp_pnom']. " " . $employe['emp_nom']; ?></h2>
	<article>
		<table>
			<tbody>
				<tr>
					<td>Prénom</td>
					<td><?php echo $employe['emp_pnom']; ?></td>
				</tr>
				<tr>
					<td>Nom</td>
					<td><?php echo $employe['emp_nom']; ?></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><a href="mailto:<?php echo $employe['emp_email']; ?>"><?php echo $employe['emp_email']; ?></a></td>
				</tr>
				<tr>
					<td>Date embauche</td>
					<td><a <?php echo $employe['emp_dateemb']; ?>"><?php echo $employe['emp_dateemb']; ?></a></td>
				</tr>
				<tr>
					<td>Téléphone</td>
					<td><a <?php echo $employe['emp_tel']; ?>"><?php echo $employe['emp_tel']; ?></a></td>
				</tr>
			</tbody>
		</table>
	</article>
</section>
<?php include "templates/footer.php";?>