
	<?php include "templates/header.php";?>
<section>
	<p><a href="?ctrl=employe&mth=add">Ajouter un employé</a></p>
	<br>
	<?php
	if (!empty($data['notification'])) {
		echo "<p>$data[notification]</p>";
	}
	?>
	<article>
		<table>
			<thead>
				<tr>
					<th>#</th>
					<th>Prénom</th>
					<th>Nom</th>
					<th>Email</th>
					<th>Téléphone</th>
					<th>Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php
				if ($data['employes']) {
					foreach ($data['employes'] as $k => $v) {
					?>
						<tr>
							<td><?php echo $k+1; ?></td>
							<td><a href="?ctrl=employe&mth=show&id=<?php echo $v['emp_id']; ?>"><?php echo $v['emp_pnom']; ?></a></td>
							<td><a href="?ctrl=employe&mth=show&id=<?php echo $v['emp_id']; ?>"><?php echo $v['emp_nom']; ?></a></td>
							<td><a href="mailto:<?php echo $v['emp_email']; ?>"><?php echo $v['emp_email']; ?></a></td>
							<td><a href="tel:<?php echo $v['emp_tel']; ?>"><?php echo $v['emp_tel']; ?></a></td>
				
							<td>
								<a href="?ctrl=employe&mth=edit&id=<?php echo $v['emp_id']; ?>">Modifier |</a>
								<a href="?ctrl=employe&mth=delete&id=<?php echo $v['emp_id']; ?>">Supprimer</a>
							</td>
						</tr>
					<?php
					}
				} else { ?>
					<tr>
						<td colspan="6">Pas d'employé</td>
					</tr>
				<?php
				}
				?>
			</tbody>
		</table>
	</article>
</section>

<?php include "templates/footer.php";?>

