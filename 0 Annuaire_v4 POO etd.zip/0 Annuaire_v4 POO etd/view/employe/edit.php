<?php include "templates/header.php";?>
<section>
    <h2>Modifier la fiche de <?php echo $employe['emp_pnom']. " " . $employe['emp_nom']; ?></h2>
    <article>
        <form action="?ctrl=employe&mth=edit&id=<?=$employe['emp_id']?>" method="post">
            <label for="prenom">Prénom</label><br>
            <input type="text" name="prenom" id="prenom" value=<?php echo $employe['emp_pnom']; ?>> <br><br>
            <label for="nom">Nom</label><br>
            <input type="text" name="nom" id="nom" value=<?php echo $employe['emp_nom']; ?>><br><br>
            <label for="email">Adresse mail</label><br>
            <input type="text" name="email" id="email" value=<?php echo $employe['emp_email'];?>><br><br>
            <label for="dateEmb">Date embauche</label><br>
            <input type="date" name="dateEmb" id="dateEmb" value=<?php echo $employe['emp_dateemb'];?>><br><br>
            <label for="tel">Téléphone </label><br>
            <input type="text" name="tel" id="tel" value=<?php echo $employe['emp_tel'];?>>
            <br><br>
            <input type="submit" name="submit" value="Modifier">
            <br><br>

            <?php if ($errors) { ?>
                    <h3>Error:</h3>
                    <ul>
                        <?php foreach ($errors as $value) { ?>
                            <li><?php echo $value; ?></li>
                        <?php } ?>
                    </ul>
            <?php } ?>
        </form>
    </article>
</section>
<?php include "templates/footer.php";?>